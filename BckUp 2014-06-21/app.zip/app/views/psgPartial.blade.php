<script type="text/javascript">
$(function(){

	$(".editableC").editable();
});
</script>

{{ $passangers->links() }}

<table class="table striped">
	<thead style="font-weight:bold">
		<tr>
			<td>Ime</td>
			<td>Prezime</td>
			<td>Adresa</td>
			<!-- <td>Pol</td>
			<td>Telefon</td> -->
			<td>Mobilni</td>
			<!-- <td>Datum rođenja</td> -->
			<td>Broj Pasoša</td>
			<td>JMBG</td>
			<td></td>
			<td></td>
		</tr>
	</thead>
	<tbody>
	@foreach ($passangers as $passanger)
	<tr>
		<td>
			{{ $passanger->name }}
		</td>
		<td>
			{{ $passanger->surname }}
		</td>
		<td>
			{{ $passanger->address }}
		</td>
		<!-- <td><a href="#" class="editableC" id="gender" data-type="text" data-pk= {{$passanger->id}} data-url="/passangerEdit/{{$passanger->id}}" data-title="Unesite pol putnika (m/f)">
			{{ $passanger->gender }}</a></td>
		<td><a href="#" class="editableC" id="tel" data-type="text" data-pk= {{$passanger->id}} data-url="/passangerEdit/{{$passanger->id}}" data-title="Unesite broj telefona putnika">
			{{ $passanger->tel }}</a></td>  -->
		<td>
			{{ $passanger->mob }}</td>
		<!-- <td><a href="#" class="editableC" id="birth_date" data-type="text" data-pk= {{$passanger->id}} data-url="/passangerEdit/{{$passanger->id}}" data-title="Unesite datum rođenja putnika (yyyy/mm/dd)">
			{{ $passanger->birth_date }}</a></td>  -->
		<td>
			{{ $passanger->passport }}</td>
		<td>
			{{ $passanger->jmbg }}
		</td>
		<td>
			<a class="passangerDetails btn btn-primary pull-right" name="{{$passanger->id}}" role="button" data-toggle="modal" href="#psgDetailModal">
			<span class="icon-edit"></span>
		</td>
		<td>
		@if (Passangers::canDelete($passanger->id))
			<a href="deletePassanger/{{(string)$passanger->id}}" class="btn btn-danger pull-right">
			<span class="icon-trash"></span>
		@endif
		</td>
	</tr>
	@endforeach
	</tbody>
</table>
