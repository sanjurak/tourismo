@section('javascripts')
	{{HTML::script('scripts/reservationsMain.js')}}
@stop
<script type="text/javascript">
$(function(){

	$(".editableC").editable();
	
	$(".editReservation").click(function(event){
	
		event.preventDefault();
		
		$resid = $(this).attr("name");
		
		$.ajax({
			url: "editReservation/" + $resid,
			type: "GET",
			success: function(data)
			{
				$("#reservations").empty().html(data);
			},
			error:function(){
				alert("ERROR");
			}
		});
	});
});
</script>

{{$reservations->links()}}

<table class="table table-hover">
		<tr>
			<th>Broj rezervacije</th>
			<th>Datum rezervacije</th>
			<th>Organizator putovanja</th>
			<th>Destinacija</th>
			<th>Status rezervacije</th>
			<th></th>
		</tr>
@foreach($reservations as $reservation)
	<tr class="{{$reservation->payment_status()}}">
		<td>			
			{{$reservation->reservation_number}}
			@if ($reservation->internal)
				<span class="icon-info-sign"></span>
			@endif
		</td>
		<td>			
			{{$reservation->reservation_date}}
			
		</td>
		<td>
			{{$reservation->traveldeal->organizer->name}}
		</td>
		<td>
			{{$reservation->traveldeal->destination->name}}
		</td>
		<td>
			{{$reservation->status}}
		</td>
		<td>
			<a role="button" class="paymentNewModal btn btn-default btn-small" name="{{$reservation->id}}" id="addNewPayment" data-toggle="modal" href="#paymentNewModal" title="Dodaj novo plaćanje">
				<span class="icon-plus"></span>
			</a>
			<a role="button" class="btn btn-default btn-small" name="contract{{$reservation->id}}" id="printContract" href="contract/{{$reservation->id}}" target="_blank" title="Štampa ugovora">
				<span class="icon-print"></span>
			</a>
			
			<a role="button" class="btn btn-default btn-small editReservation" name="{{$reservation->id}}"  href="#" title="Izmena rezervacije">
				<span class="icon-edit"></span>
			</a>
			@if (Auth::user()->isAdmin())
			<a role="button" class="btn btn-default btn-small" name="delete{{$reservation->id}}" id="delReservation" href="reservation/delete/{{$reservation->id}}" title="Brisanje rezervacije">
				<span class="icon-trash"></span>
			</a>
			@endif
		</td>
	</tr>
@endforeach
</table>